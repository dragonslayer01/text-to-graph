from flask import Flask
import boto3
import json
from flask import request

app = Flask(__name__)


@app.route('/')
def hello_world():
    return 'Hello World!'

@app.route('/readmsg', methods=["GET"])
def readmsg():
    # Create SQS client
    sqs = configureaws()

    queue_url = 'https://sqs.us-west-1.amazonaws.com/349592806832/queuemanger02'

    # Receive message from SQS queue
    response = sqs.receive_message(
        QueueUrl=queue_url,
       # MaxNumberOfMessages=1,
        VisibilityTimeout=0,
       # WaitTimeSeconds=0
    )
    # Delete received message from queue
    #sqs.delete_message(
    #    QueueUrl=queue_url,
    #    ReceiptHandle=receipt_handle
    #)
    print('Received and deleted message: %s' % response)
    return response


def configureaws():
    client = boto3.client(
        'sqs',
        region_name='us-west-1',
        aws_access_key_id='AKIAVCZK24WYEXYH6QKS',
        aws_secret_access_key='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',
    )
    return client


@app.route('/postmsg', methods=["POST"])
def postmessage():
    body = request.json
    print(body)

    sqs = configureaws()

    queue_url = 'https://sqs.us-west-1.amazonaws.com/349592806832/queuemanger02'

    # Send message to SQS queue
    response = sqs.send_message(
        QueueUrl=queue_url,
        DelaySeconds=10,
        MessageBody=json.dumps(body['message'])
    )
    print(response)
    return response


if __name__ == '__main__':
    app.run()
